function doSearch(this) {
		var q = document.getElementById(this);
		var v = q.value.toLowerCase();
		var rows = document.getElementsByTagName("tr");
		var on = 0;
		for (var i = 0; i < rows.length; i++) {
			var fileds = rows[i].getElementsByTagName("td");
			fileds = fileds[0].innerHTML.toLowerCase();
			if (fileds) {
				if (v.length == 0 || (v.length < 3 && fileds.indexOf(v) == 0)
						|| (v.length >= 3 && fileds.indexOf(v) > -1)) {
					rows[i].style.display = "";
					on++;
				} else {
					rows[i].style.display = "none";
				}
			}
		}
		var n = document.getElementById("noresults");
		if (on == 0 && n) {
			n.style.display = "";
			document.getElementById("qt").innerHTML = q.value;
		} else {
			n.style.display = "none";
		}
	}