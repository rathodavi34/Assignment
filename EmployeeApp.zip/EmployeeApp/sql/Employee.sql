CREATE TABLE `employee` (
	`firstname` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`lastname` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`emailid` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	PRIMARY KEY (`firstname`) USING BTREE
)
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB
;
