package sudoku;

public class Sudoku {
	/**
	 * Solves "in-place" the sudoku in the provided array this method signature is
	 * 
	 * @param sudoku a 9x9 array representing a sudoku, empty cells are 0
	 * @return true if the sudoku has been sucessfully solved
	 */
	public static boolean solve(int[][] sudoku) {
		return new Solver(sudoku).solve();
	}

	public static String asString(int[][] sudoku) {
		return new Board(sudoku).toString();
	}
}
