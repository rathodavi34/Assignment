CREATE SCHEMA demo;
use demo;
CREATE TABLE `employee` (
	`firstname` VARCHAR(50) NOT NULL ,
	`lastname` VARCHAR(50) NOT NULL ,
	`emailid` VARCHAR(50) NOT NULL ,
	PRIMARY KEY (`firstname`) 
)
ENGINE=InnoDB
;

